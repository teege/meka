Unpacked allegro-5.0.10-msvc-9.0.zip
From https://www.allegro.cc/files/
  
Kept:
  include/*
  lib/*-static-*

Deleted:
  bin/*
  other files from lib/
