#define ALLEGRO_CFG_ACODEC_FLAC
#define ALLEGRO_CFG_ACODEC_MODAUDIO
#define ALLEGRO_CFG_ACODEC_VORBIS
/* #undef ALLEGRO_CFG_ACODEC_TREMOR */

/* Define if the library should be loaded dynamically. */
/* #undef ALLEGRO_CFG_ACODEC_FLAC_DLL */
/* #undef ALLEGRO_CFG_ACODEC_DUMB_DLL */
/* #undef ALLEGRO_CFG_ACODEC_VORBISFILE_DLL */
